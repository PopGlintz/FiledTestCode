﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Filed_Coding_Test.Validator
{
    public class PositiveNumber : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            decimal amount = (decimal)value;
            if (amount > 0)
            {
                return true;
            }
            return false;
        }
    }
}
