﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Filed_Coding_Test.Models;
using Filed_Coding_Test.Models.ViewModels;

namespace Filed_Coding_Test.Controllers
{
    public class PaymentController : Controller
    {
        private IPaymentRepository repository;

        public PaymentController(IPaymentRepository repo)
        {
            repository = repo;
        }

        [HttpPost]
        [Route("/Process-Payment")]
        public IActionResult ProcessPayment(Payment paymentModel)
        {
            //Validate Api Call Data
            if (ModelState.IsValid)
            {
                //unitTest
                Regex cardReg = new Regex("^[1-9][0-9]{3}(-[0-9]{4}){3}$");
                Regex secureReg = new Regex("^[0-9]{3}$");
                if (!(paymentModel.Amount > 0) || !cardReg.IsMatch(paymentModel.CreditCardNumber) || paymentModel.ExpirationDate < DateTime.UtcNow 
                    || string.IsNullOrEmpty(paymentModel.CardHolder) || (!string.IsNullOrEmpty(paymentModel.SecurityCode) &&
                    !secureReg.IsMatch(paymentModel.SecurityCode)))
                {
                    return BadRequest();
                }

                //Add Payment
                Payment payment = new Payment()
                {
                    Amount = paymentModel.Amount,
                    CreditCardNumber = paymentModel.CreditCardNumber,
                    CardHolder = paymentModel.CardHolder,
                    ExpirationDate = paymentModel.ExpirationDate,
                    SecurityCode = paymentModel.SecurityCode,
                };
                if (paymentModel.Amount <= 20)
                {
                    //try cheap payment gateway
                } 
                else if (paymentModel.Amount > 20 && paymentModel.Amount <= 500)
                {
                    //try expensive payment gateway
                    //if failed, try cheap payment gateway
                }
                else
                {
                    //try premium payment service
                    //while failed and trial count is less than 3, retry
                }
                payment.PaymentState = PaymentState.processed;
                repository.AddPayment(payment);
                return Ok();
            }
            return BadRequest(ModelState);
        }
    }
}