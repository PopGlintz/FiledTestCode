﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Filed_Coding_Test.Models
{
    public interface IPaymentRepository
    {
        IQueryable<Payment> Payments { get; }

        void AddPayment(Payment payment) { }
    }
}
