﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Filed_Coding_Test.Models
{
    public class EFPaymentRepository : IPaymentRepository
    {
        private ApplicationDbContext context;

        public EFPaymentRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IQueryable<Payment> Payments => context.Payments;

        public void AddPayment(Payment payment)
        {
            context.Payments.Add(payment);
            context.SaveChanges();
        }
    }
}
