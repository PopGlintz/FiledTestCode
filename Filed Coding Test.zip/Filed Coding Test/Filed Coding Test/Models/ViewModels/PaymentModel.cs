﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Filed_Coding_Test.Validator;

namespace Filed_Coding_Test.Models.ViewModels
{
    public class PaymentModel
    {
        [Required(ErrorMessage = "Credit card number is required")]
        [RegularExpression("^[1-9][0-9]{3}(-[0-9]{4}){3}$", ErrorMessage = "Invalid credit card number")]
        public string CreditCardNumber { get; set; }

        [Required(ErrorMessage = "Card holder is required")]
        public string CardHolder { get; set; }

        [Required]
        [FutureDate(ErrorMessage = "Expiration date cannot be in the past")]
        public DateTime ExpirationDate { get; set; }

        [RegularExpression("[0-9]{3}", ErrorMessage = "Invalid security code")]
        public string SecurityCode { get; set; }

        [Required]
        [PositiveNumber(ErrorMessage = "Amount must be greater than zero")]
        public decimal Amount { get; set; }
    }
}
