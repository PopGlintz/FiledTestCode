﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Filed_Coding_Test.Controllers;
using Filed_Coding_Test.Models;
using Moq;
using Xunit;

namespace Filed_Coding_Test.Test
{
    public class PaymentTest
    {
        [Fact]
        public void TestAllParameters()
        {
            //Arrange
            var mock = new Mock<IPaymentRepository>();
            var data = new[]
            {
                new Payment()
                {
                    CreditCardNumber = "5533-3333-2323-2345",
                    CardHolder = "Ayodele Oluwafemi Samuel",
                    ExpirationDate = DateTime.UtcNow.AddYears(1),
                    SecurityCode = "123",
                    Amount = 20
                }
            }.AsQueryable<Payment>();
            mock.SetupGet(m => m.Payments).Returns(data);
            PaymentController controller = new PaymentController(mock.Object)
            {
                
            };

            //Act
            var result = controller.ProcessPayment(data.First());

            //Assert
            Assert.Equal(controller.Ok().ToString(), result.ToString());
        }
    }
}
